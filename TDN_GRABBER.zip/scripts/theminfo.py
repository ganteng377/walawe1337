import requests, re, warnings, os
from colorama import Fore, Style

warnings.filterwarnings("ignore")

hd = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/5310.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/5310.36'
}

def grabplugins():
    firstpage = int(input('First_Page (ex: 1) : '))
    lastpage = int(input('Last_Page (ex: 50,100) : '))
    sub_first = int(input('Sub_Page First (ex: 1) : '))
    sub_last = int(input('Sub_Page Last (ex: 20) : '))
    all_domains = set()
    for page in range(firstpage, lastpage + 1):
        try:
            list_url = f'https://themesinfo.com/wordpress-plugins/{page}'
            response = requests.get(list_url, headers=hd, timeout=25).text
            plugin_matches = re.findall(r'<a href="https://themesinfo.com/wordpress-plugins/(.*?)"', response)
            plugin_slugs = list(set(plugin_matches))
            if plugin_slugs:
                for slug in plugin_slugs:
                    plugin_url = f'https://themesinfo.com/wordpress-plugins/{slug}'
                    print(f'{Fore.WHITE}[{Fore.YELLOW}PLUGINS{Fore.WHITE}] {plugin_url}')
                    collected = set()
                    for sub_page in range(sub_first, sub_last + 1):
                        full_url = f'{plugin_url}/{sub_page}'
                        try:
                            sub_resp = requests.get(full_url, headers=hd, timeout=25).text
                            domains = re.findall(r'<p class="theme_web_h2">(.*?)</p>', sub_resp)
                            for domain in domains:
                                domain = domain.strip()
                                if domain:
                                    collected.add(domain)
                        except Exception as e:
                            print(f"[{Fore.RED}ERROR{Style.RESET_ALL}] {full_url} → {e}")

                    if collected:
                        print(f'{Fore.WHITE}[{Fore.GREEN}TOTAL DOMAIN{Fore.WHITE}] {len(collected)}')
                        with open('results/plugin_sites.txt', 'a', encoding='utf-8') as f:
                            for d in sorted(collected):
                                all_domains.add(d)
                                f.write(d + '\n')
                    else:
                        print(f"{Fore.YELLOW} → Tidak ada domain ditemukan pada plugin ini.{Style.RESET_ALL}")
        except Exception as e:
            print(f"[{Fore.RED}ERROR{Style.RESET_ALL}] Page {page} → {e}")

    print(f"\n{Fore.GREEN}[DONE]{Fore.WHITE} Total Unique Domains Collected: {Fore.WHITE}{len(all_domains)}{Style.RESET_ALL}")

grabplugins()
