import requests, re, warnings, os
from colorama import Fore, Style
from multiprocessing.dummy import Pool

warnings.filterwarnings("ignore")

hd = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/5310.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/5310.36'
}

firstpage = lastpage = 0

def themetix(keyword):
    found = set()
    for page in range(firstpage, lastpage + 1):
        try:
            list_url = f'https://themetix.com/search-sites/{keyword}/{page}'
            print(f'{Fore.WHITE}[{Fore.YELLOW}GRABBER{Fore.WHITE}] {list_url}')
            resp = requests.get(list_url, headers=hd, timeout=25).text

            matches = re.findall(r'onclick="location.href=\'/site/(.*?)\'"', resp)
            for domain in matches:
                clean = domain.strip()
                if clean:
                    found.add(clean)

        except Exception as e:
            print(f"[{Fore.RED}ERROR page {page}{Style.RESET_ALL}] → {e}")

    if found:
        os.makedirs("results", exist_ok=True)
        result_path = 'results/themetix_sites.txt'
        with open(result_path, 'a', encoding='utf-8') as f:
            for d in sorted(found):
                f.write(d + '\n')
        print(f'{Fore.WHITE}[{Fore.GREEN}SAVED{Fore.WHITE}] Keyword: {keyword} → {len(found)} domain(s)')
    else:
        print(f"{Fore.YELLOW}[INFO] No domains found for keyword [{keyword}]\n")

def main():
    global firstpage, lastpage
    file_name = input('List_Keyword ex(shop,travel,games) in list.txt:')
    if not os.path.exists(file_name):
        print(f"[ERROR] File not found: {file_name}")
        return

    try:
        firstpage = int(input('First_Page (ex: 1) : '))
        lastpage = int(input('Last_Page (ex: 50,100) : '))
        with open(file_name, 'r', encoding='utf-8', errors='ignore') as f:
            keywords = [line.strip() for line in f if line.strip()]
        if not keywords:
            print("[ERROR] No keywords found in the file.")
            return
        threadpool = Pool(5)
        threadpool.map(themetix, keywords)
    except Exception as e:
        print(f"[ERROR] Unable to process file: {e}")

if __name__ == '__main__':
    main()
