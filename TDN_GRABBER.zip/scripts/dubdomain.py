import requests, re, warnings, os
from colorama import Fore, Style

warnings.filterwarnings("ignore")

hd = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/5310.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/5310.36'
}

def dubdomain():
    firstpage = int(input('First_Page (ex: 1) : '))
    lastpage = int(input('Last_Page (ex: 50,100) : '))
    all_domains = set()
    for path in range(firstpage, lastpage + 1):
        try:
            url = f'https://www.dubdomain.com/index.php?page={path}'
            print(f"{Fore.WHITE}[{Fore.YELLOW}PROCESSING{Fore.WHITE}] Page {path} → {url}")
            response = requests.get(url, headers=hd, timeout=25).text
            matches = re.findall(r'data-src="(.*?)"', response)
            if matches:
                for doms in matches:
                    domain = doms.replace('https://www.google.com/s2/favicons?domain_url=', '').strip()
                    all_domains.add(domain)
        except Exception as e:
            print(f"[{Fore.RED}ERROR page {path}{Style.RESET_ALL}] → {e}")

    total = len(all_domains)
    if total > 0:
        with open('results/domain_regis.txt', 'a', encoding='utf-8') as f:
            for domain in sorted(all_domains):
                f.write(domain + '\n')
        print(f"{Fore.WHITE}[{Fore.GREEN}DONE{Fore.WHITE}] Total unique domains found: {Fore.CYAN}{total}{Style.RESET_ALL}")
    else:
        print(f"{Fore.YELLOW}[INFO] No domains found in the given page range.")

dubdomain()
