import requests, re, warnings, os, socket
from colorama import Fore, Style
from multiprocessing.dummy import Pool
from functools import partial

warnings.filterwarnings("ignore")
hd = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/5310.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/5310.36'
}

def domtoip(dom, source=""):
    try:
        ip = socket.gethostbyname(dom)
        print(Fore.GREEN + f"[FOUND] {dom} -> {ip} ({source})" + Style.RESET_ALL)
        with open('res_ips.txt', 'a', encoding='utf-8') as f:
            f.write(ip + '\n')
    except:
        print(Fore.RED + f"[ERROR] {dom} (from {source})" + Style.RESET_ALL)


def main():
    print("1. Input from single file (ex: list.txt)")
    print("2. Bulk domain-to-IP from folder (ex: /results)")
    pilihan = input("Choose [1/2]: ")

    jobs = []

    if pilihan == '1':
        file_name = input('Input file name: ')
        if not os.path.exists(file_name):
            print(f"[ERROR] File not found: {file_name}")
            return
        with open(file_name, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                domain = line.strip()
                if domain:
                    jobs.append((domain, file_name))

    elif pilihan == '2':
        folder_name = input('Input folder name: ')
        if not os.path.isdir(folder_name):
            print(f"[ERROR] Folder not found: {folder_name}")
            return
        for fname in os.listdir(folder_name):
            if fname.endswith(".txt"):
                path = os.path.join(folder_name, fname)
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    for line in f:
                        domain = line.strip()
                        if domain:
                            jobs.append((domain, fname))

    else:
        print("[ERROR] Invalid choice.")
        return

    if not jobs:
        print("[ERROR] No domain entries found.")
        return
    pool = Pool(30)
    pool.starmap(domtoip, jobs)

if __name__ == '__main__':
    main()
