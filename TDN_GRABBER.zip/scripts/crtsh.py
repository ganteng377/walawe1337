import requests, re, warnings, os
from colorama import Fore, Style
from multiprocessing.dummy import Pool

warnings.filterwarnings("ignore")
hd = {'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/5310.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/5310.36'}

def crtsh():
    keyword = input('List_Keyword ex(shop,travel,games): ')
    url = f'https://crt.sh/?q={keyword}'
    try:
        response = requests.get(url, headers=hd, timeout=40).text
        matches = re.findall(r'<TD>([\w\.-]+\.[a-z]{2,})</TD>', response)
        unique_domains = sorted(set(matches))
        result_path = f'results/crtsh_{keyword}.txt'
        with open(result_path, 'w', encoding='utf-8') as f:
            for domain in unique_domains:
                print(f"[{Fore.YELLOW}{keyword}{Style.RESET_ALL}] → {domain}")
                f.write(domain + '\n')
    except Exception as e:
        print(f"[{Fore.RED}ERROR{Style.RESET_ALL}] crt.sh for {keyword} → {e}")

crtsh()