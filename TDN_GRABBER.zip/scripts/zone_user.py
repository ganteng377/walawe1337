from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from colorama import Fore, init
from bs4 import BeautifulSoup
import time

init(autoreset=True)

def setup_driver():
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
    chrome_options.add_argument('--log-level=3')
    return webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

def handle_captcha(driver):
    try:
        print(Fore.RED + "[!] CAPTCHA detected. Please solve it manually in the browser window...")
        element = driver.find_element('xpath', "//*[text() = 'Copy the code:']")
        WebDriverWait(driver, timeout=300).until(EC.staleness_of(element))
    except Exception as e:
        print(Fore.RED + f"[!] CAPTCHA Error: {e}")

def zoneh_grabber(user, driver):
    try:
        for page in range(0, 51):
            url = f"https://www.zone-h.org/archive/notifier={user}/page={page}"
            driver.get(url)
            time.sleep(2)
            soup = BeautifulSoup(driver.page_source, 'html.parser')

            if 'Copy the code:' in soup.text:
                handle_captcha(driver)
                soup = BeautifulSoup(driver.page_source, 'html.parser')

            if 'Total notifications' in soup.text and 'Legend' in soup.text:
                try:
                    tablezoneh = soup.find('table', {'id': 'ldeface'})
                    if not tablezoneh:
                        continue
                    bodyzoneh = tablezoneh.find('tbody')
                    for tr in bodyzoneh.find_all('tr'):
                        tds = tr.find_all('td')
                        if len(tds) < 8:
                            continue
                        domain = tds[7].text.strip().split('/')[0].replace('...', '')
                        with open('results/onhold_zone.txt', 'a') as file:
                            file.write(f"{domain}\n")
                except Exception as e:
                    print(Fore.RED + f"[!] Parsing error: {e}")
    except Exception as e:
        print(Fore.RED + f"[!] Error for user {user}: {e}")

def main():
    print(Fore.YELLOW + "Zone-H Grabber Script with Selenium")
    file_name = input('List_username : ')
    with open(file_name, 'r', encoding='utf-8', errors='ignore') as f:
        users = f.read().splitlines()

    driver = setup_driver()
    print(Fore.YELLOW + "Starting to fetch data...")

    for user in users:
        print(Fore.YELLOW + f"Fetching for user: {user}")
        zoneh_grabber(user, driver)

    print(Fore.GREEN + "Finished! Check 'onhold_zone.txt' for results.")
    driver.quit()

if __name__ == "__main__":
    main()
