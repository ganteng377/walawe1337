import requests, re, warnings, os
from colorama import Fore, Style
from multiprocessing.dummy import Pool

warnings.filterwarnings("ignore")
hd = {'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/5310.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/5310.36'}

def leakix(site):
    found_domains = []
    for page in range(0, 11):
        url = f'https://leakix.net/search?page={page}&q={site}&scope=leak'
        try:
            print(f"{Fore.WHITE}[{Fore.YELLOW}GRABBER{Fore.WHITE}] [{url}]")
            response = requests.get(url, headers=hd, timeout=25).text
            matches = re.findall(r'<h5 style=""><a href="/domain/(.*?)">', response)
            if matches:
                found_domains.extend(matches)
        except:
            pass
    
    total = len(found_domains)
    if total > 0:
        print(f"{Fore.WHITE}[{Fore.GREEN}Total Domains: {total}{Fore.WHITE}] KEYWORD [{site}]")
        with open('results/result_leakix.txt', 'a', encoding='utf-8') as f:
            for domain in found_domains:
                f.write(domain + '\n')
    else:
        print(f"[INFO] No domain found for keyword or Check Your Browser and access leakix [{site}]")

def main():
    file_name = input('List_Keyword : ')
    if not os.path.exists(file_name):
        print(f"[ERROR] File not found: {file_name}")
        return

    try:
        with open(file_name, 'r', encoding='utf-8', errors='ignore') as f:
            site = f.read().splitlines()
        threadpool = Pool(10)
        threadpool.map(leakix, site)
    except Exception as e:
        print(f"[ERROR] Unable to process file: {e}")


if __name__ == '__main__':
    main()