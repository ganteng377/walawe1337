import requests, os, warnings, re
from colorama import Fore, Style
from multiprocessing.dummy import Pool as ThreadPool

warnings.filterwarnings("ignore")
hd = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/5310.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/5310.36'
}


banner = """
████████╗██████╗ ███╗   ██╗       ██████╗ ██████╗  █████╗ ██████╗ ██████╗ ███████╗██████╗ 
╚══██╔══╝██╔══██╗████╗  ██║      ██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔══██╗
   ██║   ██║  ██║██╔██╗ ██║█████╗██║  ███╗██████╔╝███████║██████╔╝██████╔╝█████╗  ██████╔╝
   ██║   ██║  ██║██║╚██╗██║╚════╝██║   ██║██╔══██╗██╔══██║██╔══██╗██╔══██╗██╔══╝  ██╔══██╗
   ██║   ██████╔╝██║ ╚████║      ╚██████╔╝██║  ██║██║  ██║██████╔╝██████╔╝███████╗██║  ██║
   ╚═╝   ╚═════╝ ╚═╝  ╚═══╝       ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝

    [GRABBER]                                                                  
[1] LeakIX Grabber
[2] Grabber Domain by Keyword (crt.sh)
[3] Grabber Domain new register (dubdomain.com)
[4] Grabber Wordpress By Plugins (ThemesInfo)
[5] Grabber Wordpress Site By Keyword (themetix)
[6] Zone-h Username Grabber (list.txt)

    [OTHER TOOLS]
[7] DOMAIN TO IP
[8] REVERSE IP
[9] SUBDOMAIN GRABBER
"""

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    os.makedirs('results', exist_ok=True)
    print(f"{Fore.YELLOW}{banner}{Style.RESET_ALL}")
    choice = input("Choose : ").strip()

    if choice == '1':
        script_path = os.path.join('scripts', 'leakix.py')
        os.system(f'python "{script_path}"')
    elif choice == '2':
        script_path = os.path.join('scripts', 'crtsh.py')
        os.system(f'python "{script_path}"')
    elif choice == '3':
        script_path = os.path.join('scripts', 'dubdomain.py')
        os.system(f'python "{script_path}"')
    elif choice == '4':
        script_path = os.path.join('scripts', 'theminfo.py')
        os.system(f'python "{script_path}"')
    elif choice == '5':
        script_path = os.path.join('scripts', 'themtix.py')
        os.system(f'python "{script_path}"')
    elif choice == '6':
        script_path = os.path.join('scripts', 'zone_user.py')
        os.system(f'python "{script_path}"')
    elif choice == '7':
        script_path = os.path.join('scripts', 'domtoip.py')
        os.system(f'python "{script_path}"')

if __name__ == '__main__':
    main()
